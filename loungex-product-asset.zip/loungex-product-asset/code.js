// Lounge'X Product Asset — 메인 스레드
// 규격: 캔버스 120x120, 콘텐츠 영역(area) 96x78 @ (12,22)
// 크기: 투명 여백 잘라낸 실제 내용이 area 안에 들어가는 최대 크기 (비율 고정)
// 정렬: area 기준 가로/세로 가운데

var CANVAS = 120;
var AREA = { x: 12, y: 22, w: 96, h: 78 };

var GRID_COLS = 10;
var GRID_GAP = 40;
var GROUP_GAP = 120;
var VARIANT_GAP = 40;

// 이름에 이게 들어간 컴포넌트는 목록에서 뺀다
var LEGACY = /-legacy/i;

figma.showUI(__html__, { width: 540, height: 700, themeColors: true });

figma.ui.postMessage({
  type: 'init',
  existing: existingNames(),
  sets: collectSets(),
  currentPage: figma.currentPage.name
});

figma.ui.onmessage = async function (msg) {
  if (msg.type === 'create') {
    var result;
    try {
      result = msg.mode === 'variant'
        ? await createVariants(msg.setId, msg.items)
        : createStandalone(msg.items);
    } catch (e) {
      result = { created: 0, errors: [{ name: '(전체)', message: errText(e) }] };
    }
    // 성공이든 실패든 항상 UI로 돌려보낸다 (버튼이 멈추지 않도록)
    figma.ui.postMessage({
      type: 'done', result: result,
      sets: collectSets(), currentPage: figma.currentPage.name
    });
    if (result.created) figma.notify('컴포넌트 ' + result.created + '개 생성');
    if (result.errors && result.errors.length) {
      figma.notify(result.errors.length + '개 실패', { error: true });
    }
  } else if (msg.type === 'refresh') {
    figma.ui.postMessage({
      type: 'sets', sets: collectSets(),
      existing: existingNames(), currentPage: figma.currentPage.name
    });
  } else if (msg.type === 'close') {
    figma.closePlugin();
  }
};

function errText(e) {
  if (!e) return '알 수 없는 오류';
  return String(e.message || e);
}

// UI에서 넘어온 바이트가 형태를 잃어도 되살린다
function toBytes(v) {
  if (v instanceof Uint8Array) return v;
  if (Array.isArray(v)) return new Uint8Array(v);
  if (v && typeof v === 'object') {
    return new Uint8Array(Object.keys(v).map(function (k) { return v[k]; }));
  }
  throw new Error('이미지 데이터를 읽지 못했습니다');
}

function pageOf(node) {
  var n = node;
  while (n && n.type !== 'PAGE') n = n.parent;
  return n;
}

function existingNames() {
  var names = [];
  try {
    var comps = figma.currentPage.findAllWithCriteria({ types: ['COMPONENT', 'COMPONENT_SET'] });
    for (var i = 0; i < comps.length; i++) names.push(comps[i].name);
  } catch (e) {}
  return names;
}

function variantProps(set) {
  var props = [];
  try {
    var defs = set.componentPropertyDefinitions;
    for (var key in defs) {
      if (defs[key] && defs[key].type === 'VARIANT') {
        props.push({ name: key, options: defs[key].variantOptions || [] });
      }
    }
  } catch (e) {}
  return props;
}

// 파일 안의 컴포넌트 세트와 각 세트의 variant 속성을 긁어온다
function collectSets() {
  var sets = [];
  try {
    sets = figma.root.findAllWithCriteria({ types: ['COMPONENT_SET'] });
  } catch (e) {
    try { sets = figma.currentPage.findAllWithCriteria({ types: ['COMPONENT_SET'] }); } catch (e2) {}
  }

  var out = [];
  for (var i = 0; i < sets.length; i++) {
    var s = sets[i];
    if (LEGACY.test(s.name)) continue;   // 구버전 컴포넌트는 목록에 안 띄운다
    var taken = [];
    for (var j = 0; j < s.children.length; j++) taken.push(s.children[j].name);
    var pg = pageOf(s);
    out.push({
      id: s.id, name: s.name, page: pg ? pg.name : '',
      props: variantProps(s), taken: taken, count: s.children.length,
      isGrid: s.layoutMode === 'GRID',
      grid: gridRows(s)
    });
  }
  return out;
}

// 격자 세트의 줄 상태를 요약한다 — UI 에서 "어느 상품에 넣을지" 목록을 만들 때 쓴다
function gridRows(set) {
  if (set.layoutMode !== 'GRID') return null;
  var props = variantProps(set);
  if (!props.length) return null;

  var used = {};
  var firstY = {};
  for (var i = 0; i < set.children.length; i++) {
    var c = set.children[i];
    var r = c.gridRowAnchorIndex;
    if (!used[r]) used[r] = [];
    used[r].push(c.gridColumnAnchorIndex);
    if (firstY[r] === undefined || c.y < firstY[r]) firstY[r] = c.y;
  }

  var labels = leftLabels(set);
  var order = Object.keys(firstY).map(Number).sort(function (a, b) { return a - b; });

  var rows = [];
  for (var j = 0; j < order.length; j++) {
    var lines = labels[j] ? readLabelLines(labels[j]) : ['', ''];
    rows.push({ i: order[j], label: lines[0], line2: lines[1], cols: used[order[j]] });
  }
  return { colCount: set.gridColumnCount, rows: rows };
}

// ---------- 1. 독립 컴포넌트로 만들기 ----------

function computeOrigin() {
  var kids = figma.currentPage.children;
  if (!kids.length) return { x: 0, y: 0 };
  var maxX = -Infinity;
  var minY = Infinity;
  for (var i = 0; i < kids.length; i++) {
    var n = kids[i];
    if (typeof n.x !== 'number') continue;
    if (n.x + n.width > maxX) maxX = n.x + n.width;
    if (n.y < minY) minY = n.y;
  }
  if (maxX === -Infinity) return { x: 0, y: 0 };
  return { x: Math.round(maxX + 200), y: Math.round(minY) };
}

function createStandalone(items) {
  var origin = computeOrigin();
  var order = [];
  var groups = {};
  for (var i = 0; i < items.length; i++) {
    var c = items[i].category || '';
    if (!groups[c]) { groups[c] = []; order.push(c); }
    groups[c].push(items[i]);
  }

  var created = [];
  var errors = [];
  var cursorY = origin.y;

  for (var g = 0; g < order.length; g++) {
    var list = groups[order[g]];
    var rows = Math.ceil(list.length / GRID_COLS);
    for (var k = 0; k < list.length; k++) {
      try {
        var comp = buildComponent(list[k]);
        comp.x = origin.x + (k % GRID_COLS) * (CANVAS + GRID_GAP);
        comp.y = cursorY + Math.floor(k / GRID_COLS) * (CANVAS + GRID_GAP);
        created.push(comp);
      } catch (e) {
        errors.push({ name: list[k].fullName, message: errText(e) });
      }
    }
    cursorY += rows * (CANVAS + GRID_GAP) + GROUP_GAP;
  }

  if (created.length) {
    figma.currentPage.selection = created;
    figma.viewport.scrollAndZoomIntoView(created);
  }
  return { created: created.length, errors: errors };
}

// ---------- 2. 기존 컴포넌트 세트에 variant로 넣기 ----------

async function createVariants(setId, items) {
  var set = figma.getNodeById(setId);
  if (!set || set.type !== 'COMPONENT_SET') {
    throw new Error('적용 컴포넌트를 찾지 못했습니다. 새로고침 후 다시 시도해주세요');
  }

  var pg = pageOf(set);
  if (pg && figma.currentPage !== pg) figma.currentPage = pg;

  var props = variantProps(set);
  var rowProp = props[0] ? props[0].name : null;
  var colProp = props[1] ? props[1].name : null;
  if (!rowProp) throw new Error('이 컴포넌트에는 variant 속성이 없습니다');

  var grid = set.layoutMode === 'GRID' ? readGrid(set, rowProp, colProp) : null;
  var labels = grid ? readLabels(set, grid) : null;

  var created = [];
  var errors = [];
  var labelOps = {};    // 줄 번호 -> { isNew, line1, line2 }
  var pendingNew = {};  // 이번에 만든 새 줄: 라벨 이름 -> 줄 번호

  try {

  for (var i = 0; i < items.length; i++) {
    var item = items[i];
    var comp = null;
    try {
      comp = buildComponent(item);

      if (!grid) {
        placeInSet(set, comp);
      } else {
        var rowIdx, colIdx, isNewRow;

        if (item.rowIndex === null || item.rowIndex === undefined) {
          // 첫 속성 값이 곧 상품인 세트 (음료) — 지금까지와 같다
          var menu = item.props[rowProp];
          isNewRow = !(menu in grid.rows);
          rowIdx = isNewRow ? addRow(set, grid, menu) : grid.rows[menu];
          colIdx = colProp
            ? colIndexFor(set, grid, item.props[colProp])
            : firstFreeCol(set, grid, rowIdx);

        } else if (item.rowIndex >= 0) {
          // 기존 상품 줄에 끼워 넣기
          isNewRow = false;
          rowIdx = item.rowIndex;
          colIdx = firstFreeCol(set, grid, rowIdx);

        } else {
          // 새 상품. 같은 라벨끼리는 한 줄을 같이 쓴다.
          var key = item.labelName || ('\u0000' + i);
          if (key in pendingNew) {
            isNewRow = false;
            rowIdx = pendingNew[key];
          } else {
            isNewRow = true;
            rowIdx = addRow(set, grid, '\u0000row' + set.gridRowCount);
            pendingNew[key] = rowIdx;
          }
          colIdx = firstFreeCol(set, grid, rowIdx);
        }

        putInCell(set, comp, rowIdx, colIdx);
        grid.cells[rowIdx + ':' + colIdx] = 1;

        var op = labelOps[rowIdx];
        if (!op) op = labelOps[rowIdx] = { isNew: false, line1: null, line2: null };
        if (isNewRow) op.isNew = true;
        if (item.labelName) op.line1 = item.labelName;
        if (item.labelOption != null && item.labelOption !== '') op.line2 = item.labelOption;
      }
      created.push(comp);
    } catch (e) {
      // 실패한 건 캔버스에 남기지 않는다
      if (comp && !comp.removed) { try { comp.remove(); } catch (e2) {} }
      errors.push({ name: item.fullName, message: errText(e) });
    }
  }

  // 라벨 생성 / 갱신
  var hasLabelWork = Object.keys(labelOps).length > 0;
  if (grid && hasLabelWork) {
    if (labels && labels.source) {
      try {
        await applyLabels(set, grid, labels, labelOps);
      } catch (e) {
        errors.push({ name: '(라벨)', message: errText(e) });
      }
    } else {
      errors.push({ name: '(라벨)', message: '기준으로 삼을 기존 라벨을 못 찾아 라벨은 만들지 않았습니다' });
    }
  }

  } finally {
    // 잠깐 꺼둔 자동 트랙 설정을 원래대로
    if (grid) restoreAutoTracks(set, grid);
  }

  if (created.length) {
    figma.currentPage.selection = created;
    figma.viewport.scrollAndZoomIntoView([set]);
  }
  return { created: created.length, errors: errors };
}

// 세트의 현재 격자 상태를 읽는다 — 어떤 메뉴가 몇 번째 줄인지, 어떤 옵션이 몇 번째 칸인지
function readGrid(set, rowProp, colProp) {
  var rows = {};      // 메뉴값 -> 줄 번호
  var cols = {};      // 옵션값 -> 칸 번호
  var cells = {};     // "row:col" -> 메뉴값
  var rowY = {};      // 줄 번호 -> 그 줄 자식의 상대 y

  for (var i = 0; i < set.children.length; i++) {
    var c = set.children[i];
    var p = parseVariantName(c.name);
    var r = c.gridRowAnchorIndex;
    var k = c.gridColumnAnchorIndex;
    cells[r + ':' + k] = p[rowProp];

    if (p[rowProp] !== undefined && !(p[rowProp] in rows)) rows[p[rowProp]] = r;
    if (colProp && p[colProp] !== undefined && !(p[colProp] in cols)) cols[p[colProp]] = k;
    if (rowY[r] === undefined) rowY[r] = c.y;
  }
  return { rows: rows, cols: cols, cells: cells, rowY: rowY };
}

function parseVariantName(name) {
  var out = {};
  var parts = String(name).split(',');
  for (var i = 0; i < parts.length; i++) {
    var eq = parts[i].indexOf('=');
    if (eq === -1) continue;
    out[parts[i].slice(0, eq).trim()] = parts[i].slice(eq + 1).trim();
  }
  return out;
}

// 트랙을 하나 늘리고 크기를 첫 트랙에 맞춘다.
//
// gridAutoTracks 가 켜진(ROWS/COLUMNS) 세트는 개수를 직접 못 바꾼다. 그렇다고 그냥 appendChild
// 하면 중간에 빈 칸이 있을 때 거기로 들어가버린다. 그래서 자동을 잠깐 끄고 늘린 뒤,
// 작업이 다 끝나면 state.autoRestore 로 원래 값을 되돌린다.
function growTrack(set, countKey, sizesKey, state) {
  var idx = set[countKey];
  var sizes = set[sizesKey];
  var ref = sizes && sizes[0] ? { type: sizes[0].type, value: sizes[0].value } : null;

  try {
    set[countKey] = idx + 1;
  } catch (e) {
    if (state && !('autoRestore' in state)) state.autoRestore = set.gridAutoTracks;
    set.gridAutoTracks = 'NONE';
    set[countKey] = idx + 1;
  }

  // 새 트랙 크기를 첫 트랙과 같게 (이 파일은 HUG)
  try {
    var t = set[sizesKey][idx];
    if (ref && t) {
      t.type = ref.type;
      if (ref.type === 'FIXED') t.value = ref.value;
    }
  } catch (e) {}

  return idx;
}

function restoreAutoTracks(set, state) {
  if (!state || !('autoRestore' in state)) return;
  try { set.gridAutoTracks = state.autoRestore; } catch (e) {}
  delete state.autoRestore;
}

function addRow(set, grid, menu) {
  var idx = growTrack(set, 'gridRowCount', 'gridRowSizes', grid);
  grid.rows[menu] = idx;
  return idx;
}

// 그 줄에서 처음 비는 칸. 다 찼으면 칸을 하나 늘린다.
function firstFreeCol(set, grid, rowIdx) {
  var n = set.gridColumnCount;
  for (var c = 0; c < n; c++) {
    if (!((rowIdx + ':' + c) in grid.cells)) return c;
  }
  return growTrack(set, 'gridColumnCount', 'gridColumnSizes', grid);
}

function colIndexFor(set, grid, opt) {
  if (opt in grid.cols) return grid.cols[opt];
  var idx = growTrack(set, 'gridColumnCount', 'gridColumnSizes', grid);
  grid.cols[opt] = idx;
  return idx;
}

// 지정한 칸에 넣는다. 칸 지정이 막히면 붙이고 나서 자리를 옮긴다.
function putInCell(set, comp, rowIdx, colIdx) {
  try {
    set.appendChildAt(comp, rowIdx, colIdx);
    return;
  } catch (e) {
    var first = e;
    try {
      set.appendChild(comp);
      comp.setGridChildPosition(rowIdx, colIdx);
    } catch (e2) {
      throw new Error((rowIdx + 1) + '번째 줄 ' + (colIdx + 1) + '번째 칸에 넣지 못했습니다 — ' +
        errText(first));
    }
  }
}

// ---------- 라벨 (세트 바깥 왼쪽) ----------

// 세트 왼쪽·세로 범위 안에 있는 형제 프레임을 라벨로 본다
function readLabels(set, grid) {
  var parent = set.parent;
  if (!parent || !parent.children) return { list: [], source: null, offset: 0, x: 0 };

  var list = leftLabels(set);
  if (!list.length) return { list: [], source: null, offset: 0, x: 0 };

  // 첫 라벨과 첫 줄의 세로 간격을 기준으로 삼는다
  var rowIdx = Object.keys(grid.rowY).map(Number).sort(function (a, b) { return a - b; });
  var firstRowAbsY = rowIdx.length ? set.y + grid.rowY[rowIdx[0]] : set.y;
  var pitch = list.length > 1 ? (list[1].y - list[0].y) : 140;

  return {
    list: list,
    source: list[0],
    offset: list[0].y - firstRowAbsY,
    pitch: pitch,
    x: list[0].x
  };
}

function labelTexts(node) {
  var texts = node.type === 'TEXT' ? [node]
    : (node.findAllWithCriteria ? node.findAllWithCriteria({ types: ['TEXT'] }) : []);
  return texts.slice().sort(function (a, b) { return a.y - b.y; });
}

// food 는 텍스트 두 개, goods 는 텍스트 하나 안에 줄바꿈. 둘 다 받는다.
function readLabelLines(node) {
  var ts = labelTexts(node);
  if (ts.length >= 2) return [ts[0].characters, ts[1].characters];
  if (ts.length === 1) {
    var parts = String(ts[0].characters).split('\n');
    return [parts[0] || '', parts.slice(1).join('\n')];
  }
  return ['', ''];
}

async function writeLabelLines(node, line1, line2) {
  var ts = labelTexts(node);
  if (ts.length >= 2) {
    if (line1 != null) await setChars(ts[0], line1);
    if (line2 != null) await setChars(ts[1], line2);
  } else if (ts.length === 1) {
    var cur = readLabelLines(node);
    var a = line1 != null ? line1 : cur[0];
    var b = line2 != null ? line2 : cur[1];
    await setChars(ts[0], b ? a + '\n' + b : a);
  }
}

// 세트 왼쪽·세로 범위 안의 형제를 y 순으로
function leftLabels(set) {
  var parent = set.parent;
  if (!parent || !parent.children) return [];
  var list = [];
  for (var i = 0; i < parent.children.length; i++) {
    var n = parent.children[i];
    if (n.id === set.id || typeof n.x !== 'number') continue;
    if (n.x >= set.x) continue;
    if (n.y < set.y || n.y > set.y + set.height) continue;
    if (!labelTexts(n).length) continue;
    list.push(n);
  }
  list.sort(function (a, b) { return a.y - b.y; });
  return list;
}

async function loadFontsOf(textNode) {
  var segs = textNode.getStyledTextSegments(['fontName']);
  for (var i = 0; i < segs.length; i++) await figma.loadFontAsync(segs[i].fontName);
  if (textNode.fontName && textNode.fontName.family) {
    await figma.loadFontAsync(textNode.fontName);
  }
}

async function setChars(textNode, value) {
  await loadFontsOf(textNode);
  textNode.characters = value;
  // 이름이 길어져도 줄바꿈되지 않도록 폭을 내용에 맞춘다
  try { textNode.textAutoResize = 'WIDTH_AND_HEIGHT'; } catch (e) {}
}

// 줄마다 라벨을 만들거나 고친다. 새 줄이면 기존 라벨을 복제해 붙인다.
async function applyLabels(set, grid, labels, ops) {
  var idxs = Object.keys(ops).map(Number).sort(function (a, b) { return a - b; });

  for (var n = 0; n < idxs.length; n++) {
    var r = idxs[n];
    var op = ops[r];
    var node = null;

    if (op.isNew) {
      node = labels.source.clone();
      set.parent.appendChild(node);
      node.name = labels.source.name;
      node.x = labels.x;

      var child = null;
      for (var j = 0; j < set.children.length; j++) {
        if (set.children[j].gridRowAnchorIndex === r) { child = set.children[j]; break; }
      }
      node.y = (child ? set.y + child.y : labels.source.y) + labels.offset;

      labels.list.push(node);
      labels.list.sort(function (a, b) { return a.y - b.y; });
    } else {
      node = labels.list[r] || null;
    }

    if (!node) continue;
    await writeLabelLines(node, op.line1, op.line2);
  }
}

// 그리드가 아닌 세트는 예전처럼 아래에 쌓는다
function placeInSet(set, comp) {
  if (set.layoutMode && set.layoutMode !== 'NONE') { set.appendChild(comp); return; }
  var left = 0, bottom = -VARIANT_GAP;
  var kids = set.children;
  if (kids.length) {
    left = Infinity; bottom = -Infinity;
    for (var i = 0; i < kids.length; i++) {
      if (kids[i] === comp) continue;
      if (kids[i].x < left) left = kids[i].x;
      if (kids[i].y + kids[i].height > bottom) bottom = kids[i].y + kids[i].height;
    }
    if (left === Infinity) { left = 0; bottom = -VARIANT_GAP; }
  }
  set.appendChild(comp);
  comp.x = left;
  comp.y = bottom + VARIANT_GAP;
  var needW = comp.x + comp.width, needH = comp.y + comp.height;
  if (needW > set.width || needH > set.height) {
    set.resizeWithoutConstraints(Math.max(set.width, needW), Math.max(set.height, needH));
  }
}

// ---------- 공통: 규격에 맞춘 프레임 + 컴포넌트화 ----------

function buildComponent(item) {
  var bbox = item.bbox, imgW = item.imgW, imgH = item.imgH;

  // area 안에 들어가는 최대 배율 (비율 고정)
  var s = Math.min(AREA.w / bbox.w, AREA.h / bbox.h);
  // 이미지 전체를 s배로 놓되, 내용의 중심이 area 중심에 오도록 위치를 민다
  var rx = AREA.x + AREA.w / 2 - s * (bbox.x + bbox.w / 2);
  var ry = AREA.y + AREA.h / 2 - s * (bbox.y + bbox.h / 2);

  var frame = figma.createFrame();
  frame.resizeWithoutConstraints(CANVAS, CANVAS);
  frame.name = item.fullName;
  frame.fills = [];
  frame.clipsContent = true;

  var image = figma.createImage(toBytes(item.bytes));
  var rect = figma.createRectangle();
  frame.appendChild(rect);
  rect.name = 'image';
  rect.resizeWithoutConstraints(Math.max(0.01, imgW * s), Math.max(0.01, imgH * s));
  rect.x = rx;
  rect.y = ry;
  rect.fills = [{ type: 'IMAGE', imageHash: image.hash, scaleMode: 'FILL' }];

  var comp = figma.createComponentFromNode(frame);
  comp.name = item.fullName;
  return comp;
}
